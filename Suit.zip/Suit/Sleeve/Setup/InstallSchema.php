<?php

namespace Suit\Sleeve\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class InstallSchema implements InstallSchemaInterface
{
        
        
        
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
                
                
        $installer = $setup;
        $installer->startSetup();
                
                
        /**
                        * Create table 'suit_sleeve'
                */
                
        $table = $installer->getConnection()->newTable($installer->getTable('suit_sleeve'))
                                ->addColumn(
                                    'suit_sleeve_id',
                                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                                    null,
                                    ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                                    'Sleeves ID'
                                )
                                ->addColumn(
                                    'title',
                                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                                    255,
                                    ['nullable' => true, 'default' => null],
                                    'Title'
                                )
                                ->addColumn(
                                    'class',
                                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                                    255,
                                    ['nullable' => true, 'default' => null],
                                    'class'
                                )
                                ->addColumn(
                                    'suit_sleeveimage',
                                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                                    255,
                                    [],
                                    'Sleeve Image'
                                )
                                ->addColumn(
                                    'suit_sleevethreadimage',
                                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                                    255,
                                    [],
                                    'suit_sleevethreadimage Image'
                                )
                                ->addColumn(
                                    'link',
                                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                                    255,
                                    [],
                                    'Link'
                                )
                                ->addColumn(
                                    'target',
                                    \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                                    255,
                                    [],
                                    'Target'
                                )
                                ->addColumn(
                                    'sort_order',
                                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                                    null,
                                    ['nullable' => false, 'unsigned' => true, 'default' => '0'],
                                    'Sort Order'
                                )
                                ->addColumn(
                                    'status',
                                    \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
                                    null,
                                    ['nullable' => false, 'unsigned' => true, 'default' => '1'],
                                    'Date'
                                )
                                ->addColumn(
                                    'style',
                                    \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
                                    null,
                                    ['nullable' => false, 'unsigned' => true, 'default' => '0'],
                                    'style'
                                )
                                ->addColumn(
                                    'sleeve',
                                    \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
                                    null,
                                    ['nullable' => false, 'unsigned' => true, 'default' => '0'],
                                    'sleeve'
                                )
                                ->addColumn(
                                    'size',
                                    \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
                                    null,
                                    ['nullable' => false, 'unsigned' => true, 'default' => '0'],
                                    'size'
                                )
                                ->addColumn(
                                    'created_time',
                                    \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                                    null,
                                    ['nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT],
                                    'Creation Time'
                                )
                                ->addColumn(
                                    'update_time',
                                    \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                                    null,
                                    ['nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT_UPDATE],
                                    'Update Time'
                                );
                
                
        $installer->getConnection()->createTable($table);
                
        $installer->endSetup();
    }
}
