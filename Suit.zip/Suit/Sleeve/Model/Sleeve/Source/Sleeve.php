<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Suit\Sleeve\Model\Sleeve\Source;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Status
 */
class Sleeve implements OptionSourceInterface
{
    
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        
        return [
            ['value' => '1', 'label' => __('2')],
            ['value' => '2', 'label' => __('3')],
            ['value' => '3', 'label' => __('4')]
        ];
    }
}
