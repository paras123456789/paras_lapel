<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Suit\Lapel\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use Magento\Backend\App\Action;
use Suit\Lapel\Model\Lapel;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\TestFramework\Inspection\Exception;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\RequestInterface;

//use Magento\Framework\Stdlib\DateTime\DateTime;
//use Magento\Ui\Component\MassAction\Filter;
//use FME\News\Model\ResourceModel\Test\CollectionFactory;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;
    protected $scopeConfig;
   
    protected $_escaper;
    protected $inlineTranslation;
    protected $_dateFactory;
    //protected $_modelNewsFactory;
  //  protected $collectionFactory;
   //  protected $filter;
    /**
     * @param Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param DataPersistorInterface $dataPersistor
     */
    public function __construct(
        Context $context,
        DataPersistorInterface $dataPersistor,
        \Magento\Framework\Escaper $escaper,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory
    ) {
       // $this->filter = $filter;
       // $this->collectionFactory = $collectionFactory;
        $this->dataPersistor = $dataPersistor;
         $this->scopeConfig = $scopeConfig;
         $this->_escaper = $escaper;
        $this->_dateFactory = $dateFactory;
         $this->inlineTranslation = $inlineTranslation;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        if ($data) {
            $id = $this->getRequest()->getParam('suit_lapel_id');

            if (isset($data['status']) && $data['status'] === 'true') {
                $data['status'] = Block::STATUS_ENABLED;
            }
            if (empty($data['suit_lapel_id'])) {
                $data['suit_lapel_id'] = null;
            }

           
            /** @var \Magento\Cms\Model\Block $model */
            $model = $this->_objectManager->create('Suit\Lapel\Model\Lapel')->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addError(__('This suit_lapel no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }

            
            if (isset($data['suit_lapelimage'][0]['name']) && isset($data['suit_lapelimage'][0]['tmp_name'])) {
                $data['suit_lapelimage'] ='/suit_lapel/'.$data['suit_lapelimage'][0]['name'];
            } elseif (isset($data['suit_lapelimage'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['suit_lapelimage'] =$data['suit_lapelimage'][0]['name'];
            } else {
                $data['suit_lapelimage'] = null;
            }
            
            
            if (isset($data['suit_lapelthreadimage'][0]['name']) && isset($data['suit_lapelthreadimage'][0]['tmp_name'])) {
                $data['suit_lapelthreadimage'] ='/suit_lapel/'.$data['suit_lapelthreadimage'][0]['name'];
            } elseif (isset($data['suit_lapelthreadimage'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['suit_lapelthreadimage'] =$data['suit_lapelthreadimage'][0]['name'];
            } else {
                $data['suit_lapelthreadimage'] = null;
            }
            
            
            if (isset($data['suit_lowerleftglow'][0]['name']) && isset($data['suit_lowerleftglow'][0]['tmp_name'])) {
                $data['suit_lowerleftglow'] ='/suit_lapel/'.$data['suit_lowerleftglow'][0]['name'];
            } elseif (isset($data['suit_lowerleftglow'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['suit_lowerleftglow'] =$data['suit_lowerleftglow'][0]['name'];
            } else {
                $data['suit_lowerleftglow'] = null;
            }
            
            
            if (isset($data['suit_lowerleftmask'][0]['name']) && isset($data['suit_lowerleftmask'][0]['tmp_name'])) {
                $data['suit_lowerleftmask'] ='/suit_lapel/'.$data['suit_lowerleftmask'][0]['name'];
            } elseif (isset($data['suit_lowerleftmask'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['suit_lowerleftmask'] =$data['suit_lowerleftmask'][0]['name'];
            } else {
                $data['suit_lowerleftmask'] = null;
            }
            
            
            if (isset($data['suit_lowerrightglow'][0]['name']) && isset($data['suit_lowerrightglow'][0]['tmp_name'])) {
                $data['suit_lowerrightglow'] ='/suit_lapel/'.$data['suit_lowerrightglow'][0]['name'];
            } elseif (isset($data['suit_lowerrightglow'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['suit_lowerrightglow'] =$data['suit_lowerrightglow'][0]['name'];
            } else {
                $data['suit_lowerrightglow'] = null;
            }
            
            
            if (isset($data['suit_lowerrightmask'][0]['name']) && isset($data['suit_lowerrightmask'][0]['tmp_name'])) {
                $data['suit_lowerrightmask'] ='/suit_lapel/'.$data['suit_lowerrightmask'][0]['name'];
            } elseif (isset($data['suit_lowerrightmask'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['suit_lowerrightmask'] =$data['suit_lowerrightmask'][0]['name'];
            } else {
                $data['suit_lowerrightmask'] = null;
            }
            
            
            if (isset($data['suit_upperleftglow'][0]['name']) && isset($data['suit_upperleftglow'][0]['tmp_name'])) {
                $data['suit_upperleftglow'] ='/suit_lapel/'.$data['suit_upperleftglow'][0]['name'];
            } elseif (isset($data['suit_upperleftglow'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['suit_upperleftglow'] =$data['suit_upperleftglow'][0]['name'];
            } else {
                $data['suit_upperleftglow'] = null;
            }
            
            
            if (isset($data['suit_upperleftmask'][0]['name']) && isset($data['suit_upperleftmask'][0]['tmp_name'])) {
                $data['suit_upperleftmask'] ='/suit_lapel/'.$data['suit_upperleftmask'][0]['name'];
            } elseif (isset($data['suit_upperleftmask'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['suit_upperleftmask'] =$data['suit_upperleftmask'][0]['name'];
            } else {
                $data['suit_upperleftmask'] = null;
            }
            
            
            if (isset($data['suit_upperrightglow'][0]['name']) && isset($data['suit_upperrightglow'][0]['tmp_name'])) {
                $data['suit_upperrightglow'] ='/suit_lapel/'.$data['suit_upperrightglow'][0]['name'];
            } elseif (isset($data['suit_upperrightglow'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['suit_upperrightglow'] =$data['suit_upperrightglow'][0]['name'];
            } else {
                $data['suit_upperrightglow'] = null;
            }
            
            
            if (isset($data['suit_upperrightmask'][0]['name']) && isset($data['suit_upperrightmask'][0]['tmp_name'])) {
                $data['suit_upperrightmask'] ='/suit_lapel/'.$data['suit_upperrightmask'][0]['name'];
            } elseif (isset($data['suit_upperrightmask'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['suit_upperrightmask'] =$data['suit_upperrightmask'][0]['name'];
            } else {
                $data['suit_upperrightmask'] = null;
            }
           
            
            
            $model->setData($data);


            $this->inlineTranslation->suspend();
            try {
                    //////////////////// email
                $model->save();
                $this->messageManager->addSuccess(__('suit_lapel Saved successfully'));
                $this->dataPersistor->clear('suit_lapel');

                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['suit_lapel_id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the suit_lapel.'));
                print_r($e);
            }

            $this->dataPersistor->set('suit_lapel', $data);
            return $resultRedirect->setPath('*/*/edit', ['suit_lapel_id' => $this->getRequest()->getParam('suit_lapel_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }
}
