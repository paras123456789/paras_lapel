<?php

namespace Jeans\Custom\Observer;

/*
Class LoginObserver for getting user's log in time data.
*/

class LoginObserver implements \Magento\Framework\Event\ObserverInterface
{
	public function execute(\Magento\Framework\Event\Observer $observer)
	{
    // echo "string"; die;
		 // print_r($observer->getData());
     echo

	}
}
