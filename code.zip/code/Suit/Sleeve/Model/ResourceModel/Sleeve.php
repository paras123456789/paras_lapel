<?php

namespace Suit\Sleeve\Model\ResourceModel;

class Sleeve extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
        
        
           
    protected function _construct()
    {
        $this->_init('suit_sleeve', 'suit_sleeve_id');
    }
}
