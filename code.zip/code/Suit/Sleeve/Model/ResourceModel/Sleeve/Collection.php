<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Suit\Sleeve\Model\ResourceModel\Sleeve;

use \Suit\Sleeve\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'suit_sleeve_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Suit\Sleeve\Model\Sleeve', 'Suit\Sleeve\Model\ResourceModel\Sleeve');
        $this->_map['fields']['suit_sleeve_id'] = 'main_table.suit_sleeve_id';
    }
}
