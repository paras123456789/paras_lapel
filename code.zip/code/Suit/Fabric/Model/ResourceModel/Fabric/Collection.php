<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Suit\Fabric\Model\ResourceModel\Fabric;

use \Suit\Fabric\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'suit_fabric_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Suit\Fabric\Model\Fabric', 'Suit\Fabric\Model\ResourceModel\Fabric');
        $this->_map['fields']['suit_fabric_id'] = 'main_table.suit_fabric_id';
    }
}
