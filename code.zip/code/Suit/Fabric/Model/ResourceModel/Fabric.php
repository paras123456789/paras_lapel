<?php

namespace Suit\Fabric\Model\ResourceModel;

class Fabric extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
        
        
           
    protected function _construct()
    {
        $this->_init('suit_fabric', 'suit_fabric_id');
    }
}
