<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Suit\Fabric\Model\Fabric\Source;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Status
 */
class ButtonColor implements OptionSourceInterface
{
    
    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        
        return [
            ['value' => '1', 'label' => __('Dark Blue')],
            ['value' => '2', 'label' => __('Black')],
            ['value' => '3', 'label' => __('Ivory')]
        ];
    }
}
