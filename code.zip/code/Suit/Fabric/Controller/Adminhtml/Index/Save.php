<?php

/**
 *
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Suit\Fabric\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use Magento\Backend\App\Action;
use Suit\Fabric\Model\Fabric;
use Suit\Lapel\Model\Lapel;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\TestFramework\Inspection\Exception;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\RequestInterface;

//use Magento\Framework\Stdlib\DateTime\DateTime;
//use Magento\Ui\Component\MassAction\Filter;
//use FME\News\Model\ResourceModel\Test\CollectionFactory;

class Save extends \Magento\Backend\App\Action {

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;
    protected $scopeConfig;
    protected $_escaper;
    protected $inlineTranslation;
    protected $_dateFactory;

    //protected $_modelNewsFactory;
    //  protected $collectionFactory;
    //  protected $filter;
    /**
     * @param Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param DataPersistorInterface $dataPersistor
     */
    public function __construct(
    Context $context, DataPersistorInterface $dataPersistor, \Magento\Framework\Escaper $escaper, \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation, \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory
    ) {
        // $this->filter = $filter;
        // $this->collectionFactory = $collectionFactory;
        $this->dataPersistor = $dataPersistor;
        $this->scopeConfig = $scopeConfig;
        $this->_escaper = $escaper;
        $this->_dateFactory = $dateFactory;
        $this->inlineTranslation = $inlineTranslation;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute() {
        // echo "dsfdsf";die;

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

        $directory = $objectManager->get('\Magento\Framework\Filesystem\DirectoryList');

        $rootPath = $directory->getRoot();
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        //echo "<pre>";
        //print_r($data);die;
        if ($data) {
            $id = $this->getRequest()->getParam('suit_fabric_id');

            if (isset($data['status']) && $data['status'] === 'true') {
                $data['status'] = Block::STATUS_ENABLED;
            }
            if (empty($data['suit_fabric_id'])) {
                $data['suit_fabric_id'] = null;
            }


            /** @var \Magento\Cms\Model\Block $model */
            $model = $this->_objectManager->create('Suit\Fabric\Model\Fabric')->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addError(__('This suit_fabric no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }


            if (isset($data['suit_fabricimage'][0]['name']) && isset($data['suit_fabricimage'][0]['tmp_name'])) {
                $data['suit_fabricimage'] = '/suit_fabric/' . $data['suit_fabricimage'][0]['name'];
            } elseif (isset($data['suit_fabricimage'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['suit_fabricimage'] = $data['suit_fabricimage'][0]['name'];
            } else {
                $data['suit_fabricimage'] = null;
            }
            $fabric_thumb_name = $data['suit_fabricimage'];

            if (isset($data['suit_plainfabricimage'][0]['name']) && isset($data['suit_plainfabricimage'][0]['tmp_name'])) {
                $data['suit_plainfabricimage'] = '/suit_fabric/' . $data['suit_plainfabricimage'][0]['name'];
            } elseif (isset($data['suit_plainfabricimage'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['suit_plainfabricimage'] = $data['suit_plainfabricimage'][0]['name'];
            } else {
                $data['suit_plainfabricimage'] = null;
            }
            $fabric_vest_thumb_name = $data['suit_plainfabricimage'];

            $model->setData($data);

// echo "dsfdsf";die;
            $this->inlineTranslation->suspend();
            try {
                //////////////////// email
                $model->save();
                $this->messageManager->addSuccess(__('suit_fabric Saved successfully'));
                $this->dataPersistor->clear('suit_fabric');

//                custom code 23/08/2017 START
                $fabric_id = $model->getId();
                $fabricThumbImgpath = $rootPath . '/pub/media' . $fabric_thumb_name;
                $fabricName = "fabric_" . $fabric_id . "_main.png";
                $fabric_0 = $rootPath . '/pub/media/fabric_images/' . $fabricName;
               // echo "\n\r" . 'convert -size 1080x1320 tile:' . $fabricThumbImgpath . ' ' . $fabric_0;
               // die;
                exec('convert -size 1080x1320 tile:' . $fabricThumbImgpath . ' ' . $fabric_0);

                /* Create plain fabric image */

                $vestfabricThumbImgpath = $rootPath . '/pub/media/' . $fabric_vest_thumb_name;
                $vestfabricName = "fabric_" . $fabric_id . "_vestmain.png";
                $vestfabric_0 = $rootPath . '/pub/media/fabric_images/' . $vestfabricName;

                /* exec("convert -size 1080x1320! xc:transparent media/fabric_images/" . $fabricName);
                  exec('convert ' . $fabric_0 . ' -fill ' . $fabricThumbImgpath . ' -set colorspace RGB -draw "color 0,0 reset" ' . $fabric_0); */

                exec('convert -size 1080x1320 tile:' . $vestfabricThumbImgpath . ' ' . $vestfabric_0);

                /* Create lapel images */

                $lapelModel = $this->_objectManager->create('Suit\Lapel\Model\Lapel');
                $collection = $lapelModel->getCollection();
                foreach ($collection as $lapel) {
                    $lapel_id = $lapel->getSuitLapelId();
                    $style_type = $lapel->getStyle();
                    $lapel_size = $lapel->getSize();
                    $lapel_type = $lapel->getLapel();

                    $lapel_glow = $rootPath . '/pub/media' . $lapel->getSuitLapelimage();
                    $lapel_mask = $rootPath . '/pub/media' . $lapel->getSuitLapelthreadimage();
                    if ($lapel->getSuitLapelimage() != '' && $lapel->getSuitLapelthreadimage() != '') {
                       // echo 'composite -compose CopyOpacity ' . $lapel_mask . ' ' . $fabric_0 . ' ' . $rootPath . '/pub/media/jacket_images/lapel/' . $fabric_id . '_lapelstyle_' . $style_type . '_size_' . $lapel_size . '_lapeltype_' . $lapel_type . '_view_1.png';die;
//                        echo 'convert '. $rootPath . '/pub/media/jacket_images/lapel/' . $fabric_id . '_lapelstyle_' . $style_type . '_size_' . $lapel_size . '_lapeltype_' . $lapel_type . '_view_1.png ' . $lapel_glow . ' -geometry +0+0 -composite '.$rootPath . '/pub/media/jacket_images/lapel/' . $fabric_id . '_lapelstyle_' . $style_type . '_size_' . $lapel_size . '_lapeltype_' . $lapel_type . '_view_1.png';
                        exec('composite -compose CopyOpacity ' . $lapel_mask . ' ' . $fabric_0 . ' ' . $rootPath . '/pub/media/jacket_images/lapel/' . $fabric_id . '_lapelstyle_' . $style_type . '_size_' . $lapel_size . '_lapeltype_' . $lapel_type . '_view_1.png');
                        exec('convert ' . $rootPath . '/pub/media/jacket_images/lapel/' . $fabric_id . '_lapelstyle_' . $style_type . '_size_' . $lapel_size . '_lapeltype_' . $lapel_type . '_view_1.png ' . $lapel_glow . ' -geometry +0+0 -composite ' . $rootPath . '/pub/media/jacket_images/lapel/' . $fabric_id . '_lapelstyle_' . $style_type . '_size_' . $lapel_size . '_lapeltype_' . $lapel_type . '_view_1.png');
                    }
                }

                /* END lapel images */

                /* Create pocket images - START */

                $pocketModel = $this->_objectManager->create('Suit\Pocket\Model\Pocket');
                $pocket_collection = $pocketModel->getCollection();
                foreach ($pocket_collection as $pocket) {
                    $pocket_id = $pocket->getSuitPocketId();
                    $pocket_glow = $rootPath . '/pub/media' . $pocket->getSuitPocketglowimage();
                    $pocket_mask = $rootPath . '/pub/media' . $pocket->getSuitPocketmaskimage();

                    if ($pocket_glow != '' && $pocket_mask != '') {
                        exec('composite -compose CopyOpacity ' . $pocket_mask . ' ' . $fabric_0 . ' ' . $rootPath . '/pub/media/jacket_images/pockets/' . $fabric_id . '_pockets_' . $pocket_id . '_view_1.png');
                        exec('convert ' . $rootPath . '/pub/media/jacket_images/pockets/' . $fabric_id . '_pockets_' . $pocket_id . '_view_1.png ' . $pocket_glow . ' -geometry +0+0 -composite ' . $rootPath . '/pub/media/jacket_images/pockets/' . $fabric_id . '_pockets_' . $pocket_id . '_view_1.png');
                    }

                    $ticket_pocket_glow = $rootPath . '/pub/media' . $pocket->getSuitPocketcollarglowimage();
                    $ticket_pocket_mask = $rootPath . '/pub/media' . $pocket->getSuitPocketcollarmaskimage();

                    if ($pocket->getSuitPocketcollarglowimage() != '' && $pocket->getSuitPocketcollarmaskimage() != '') {
                        exec('composite -compose CopyOpacity ' . $ticket_pocket_mask . ' ' . $fabric_0 . ' ' . $rootPath . '/pub/media/jacket_images/pockets/' . $fabric_id . '_ticketpockets_' . $pocket_id . '_view_1.png');
                        exec('convert ' . $rootPath . '/pub/media/jacket_images/pockets/' . $fabric_id . '_ticketpockets_' . $pocket_id . '_view_1.png ' . $ticket_pocket_glow . ' -geometry +0+0 -composite ' . $rootPath . '/pub/media/jacket_images/pockets/' . $fabric_id . '_ticketpockets_' . $pocket_id . '_view_1.png');
                    }


                    $slanted_pocket_glow = $rootPath . '/pub/media' . $pocket->getSuitPocketliningglowimage();
                    $slanted_pocket_mask = $rootPath . '/pub/media' . $pocket->getSuitPocketliningmaskimage();

                    if ($pocket->getSuitPocketliningglowimage() != '' && $pocket->getSuitPocketliningmaskimage() != '') {
                        exec('composite -compose CopyOpacity ' . $slanted_pocket_mask . ' ' . $fabric_0 . ' ' . $rootPath . '/pub/media/jacket_images/pockets/' . $fabric_id . '_slantedpockets_' . $pocket_id . '_view_1.png');
                        exec('convert ' . $rootPath . '/pub/media/jacket_images/pockets/' . $fabric_id . '_slantedpockets_' . $pocket_id . '_view_1.png ' . $slanted_pocket_glow . ' -geometry +0+0 -composite ' . $rootPath . '/pub/media/jacket_images/pockets/' . $fabric_id . '_slantedpockets_' . $pocket_id . '_view_1.png');
                    }


                    $slanted_ticket_pocket_glow = $rootPath . '/pub/media' . $pocket->getSuitPocketslantedglowimage();
                    $slanted_ticket_pocket_mask = $rootPath . '/pub/media' . $pocket->getSuitPocketslantedmaskimage();

                    if ($pocket->getSuitPocketslantedglowimage() != '' && $pocket->getSuitPocketslantedmaskimage() != '') {
                        exec('composite -compose CopyOpacity ' . $slanted_ticket_pocket_mask . ' ' . $fabric_0 . ' ' . $rootPath . '/pub/media/jacket_images/pockets/' . $fabric_id . '_slantedticketpockets_' . $pocket_id . '_view_1.png');
                        exec('convert ' . $rootPath . '/pub/media/jacket_images/pockets/' . $fabric_id . '_slantedticketpockets_' . $pocket_id . '_view_1.png ' . $slanted_ticket_pocket_glow . ' -geometry +0+0 -composite ' . $rootPath . '/pub/media/jacket_images/pockets/' . $fabric_id . '_slantedticketpockets_' . $pocket_id . '_view_1.png');
                    }
                }
                /* Create pocket images - END */

                /* Create style images START */


                $styleModel = $this->_objectManager->create('Suit\Style\Model\Style');
                $style_collection = $styleModel->getCollection();
                foreach ($style_collection as $style) {
                    $style_id = $style->getSuitStyleId();
                    $glow = $rootPath . '/pub/media' . $style->getSuitStyleglowimage();
                    $mask = $rootPath . '/pub/media' . $style->getSuitStylemaskimage();

                    if ($style->getSuitStyleglowimage() != '' && $style->getSuitStylemaskimage() != '') {
                        exec('composite -compose CopyOpacity ' . $mask . ' ' . $fabric_0 . ' ' . $rootPath . '/pub/media/jacket_images/style/' . $fabric_id . '_style_' . $style_id . '_view_1.png');
                        exec('convert ' . $rootPath . '/pub/media/jacket_images/style/' . $fabric_id . '_style_' . $style_id . '_view_1.png ' . $glow . ' -geometry +0+0 -composite ' . $rootPath . '/pub/media/jacket_images/style/' . $fabric_id . '_style_' . $style_id . '_view_1.png');
                    }


                    $collar_glow = $rootPath . '/pub/media' . $style->getSuitStylecollarglowimage();
                    $collar_mask = $rootPath . '/pub/media' . $style->getSuitStylecollarmaskimage();

                    if ($style->getSuitStylecollarglowimage() != '' && $style->getSuitStylecollarmaskimage() != '') {
                        exec('composite -compose CopyOpacity ' . $collar_mask . ' ' . $fabric_0 . ' ' . $rootPath . '/pub/media/jacket_images/collar/' . $fabric_id . '_collarstyle_' . $style_id . '_view_3.png');
                        exec('convert ' . $rootPath . '/pub/media/jacket_images/collar/' . $fabric_id . '_collarstyle_' . $style_id . '_view_3.png ' . $collar_glow . ' -geometry +0+0 -composite ' . $rootPath . '/pub/media/jacket_images/collar/' . $fabric_id . '_collarstyle_' . $style_id . '_view_3.png');
                    }


                    $lining_glow = $rootPath . '/pub/media' . $style->getSuitStyleliningglowimage();
                    $lining_mask = $rootPath . '/pub/media' . $style->getSuitStyleliningmaskimage();

                    if ($style->getSuitStyleliningglowimage() != '' && $style->getSuitStyleliningmaskimage() != '') {
                        exec('composite -compose CopyOpacity ' . $lining_mask . ' ' . $fabric_0 . ' ' . $rootPath . '/pub/media/jacket_images/lining/' . $fabric_id . '_liningstyle_' . $style_id . '_view_3.png');
                        exec('convert ' . $rootPath . '/pub/media/jacket_images/lining/' . $fabric_id . '_liningstyle_' . $style_id . '_view_3.png ' . $lining_glow . ' -geometry +0+0 -composite ' . $rootPath . '/pub/media/jacket_images/lining/' . $fabric_id . '_liningstyle_' . $style_id . '_view_3.png');
                    }
                }
                /* style images END */

                /* Jacket breast pocket START */

                $breastpocket_glow = $rootPath . '/pub/media/glow_mask/pocket/Breast_Pocket_Main_Glow.png';
                $breastpocket_mask = $rootPath . '/pub/media/glow_mask/pocket/Breast_Pocket_Main_Mask.png';

                exec('composite -compose CopyOpacity ' . $breastpocket_mask . ' ' . $fabric_0 . ' ' . $rootPath . '/pub/media/jacket_images/pockets/' . $fabric_id . '_breastpocket_view_1.png');
                exec('convert ' . $rootPath . '/pub/media/jacket_images/pockets/' . $fabric_id . '_breastpocket_view_1.png ' . $breastpocket_glow . ' -geometry +0+0 -composite ' . $rootPath . '/pub/media/jacket_images/pockets/' . $fabric_id . '_breastpocket_view_1.png');
                /* Jacket breast pocket END */

                /* Create back style images START */


                $backModel = $this->_objectManager->create('Suit\Back\Model\Back');
                $back_collection = $backModel->getCollection();
                foreach ($back_collection as $back) {
                    $back_id = $back->getSuitBackId();
                    $glow = $rootPath . '/pub/media/' . $back->getSuitBackmaskimage();
                    $mask = $rootPath . '/pub/media/' . $back->getSuitBackimage();

                    if ($back->getSuitBackmaskimage() != '' && $back->getSuitBackimage() != '') {
                        exec('composite -compose CopyOpacity ' . $mask . ' ' . $fabric_0 . ' ' . $rootPath . '/pub/media/jacket_images/style/' . $fabric_id . '_style_' . $back_id . '_view_2.png');
                        exec('convert ' . $rootPath . '/pub/media/jacket_images/style/' . $fabric_id . '_style_' . $back_id . '_view_2.png ' . $glow . ' -geometry +0+0 -composite ' . $rootPath . '/pub/media/jacket_images/style/' . $fabric_id . '_style_' . $back_id . '_view_2.png');
                    }
                }
                /*  back style images END */


                /* Create Back collor images START *//* -------NEED TO CHANGE--------------- */

//                $fitModel = $this->_objectManager->create('Suit\Fit\Model\Fit');
//                $lining_collection = $fitModel->getCollection();
//                foreach ($lining_collection as $lining) {
//                    $lining_id = $lining->getfitId();
//                    $back_collar_glow = $rootPath . '/pub/media/' . $lining->getbackCollarGlow();
//                    $back_collar_mask = $rootPath . '/pub/media/' . $lining->getbackCollarMask();
//
//                    if ($back_collar_glow != '' && $back_collar_mask != '') {
//                        exec('composite -compose CopyOpacity ' . $back_collar_mask . ' ' . $fabric_0 . ' '.$rootPath . '/pub/media/jacket_images/back_collar/' . $fabric_id . '_backCollar_' . $lining_id . '_view_1.png');
//                        exec('convert '.$rootPath . '/pub/media/jacket_images/back_collar/' . $fabric_id . '_backCollar_' . $lining_id . '_view_1.png ' . $back_collar_glow . ' -geometry +0+0 -composite '.$rootPath . '/pub/media/jacket_images/back_collar/' . $fabric_id . '_backCollar_' . $lining_id . '_view_1.png');
//                    }
//                }
                /* Create Back collor images END */

                /* Create Vest style START */

                $backvest_glow = $rootPath . '/pub/media/glow_mask/veststyle/Back_Vest_glow.png';
                $backvest_mask = $rootPath . '/pub/media/glow_mask/veststyle/Back_Vest_mask.png';

                $veststyleModel = $this->_objectManager->create('Vest\Veststyle\Model\Veststyle');
                $veststyle_collection = $veststyleModel->getCollection();
                foreach ($veststyle_collection as $veststyle) {
                    $veststyle_id = $veststyle->getVestVeststyle_id();
                    $vstyle_id = $veststyle->getStyle();
                    $bottom = $veststyle->getLapel();
                    $veststyle_glow = $rootPath . '/pub/media/' . $veststyle->getVestVeststyleglowimage();
                    $veststyle_mask = $rootPath . '/pub/media/' . $veststyle->getVestVeststylemaskimage();

                    if ($veststyle->getVestVeststyleglowimage() != '' && $veststyle->getVestVeststylemaskimage() != '') {
                        exec('composite -compose CopyOpacity ' . $veststyle_mask . ' ' . $fabric_0 . ' ' . $rootPath . '/pub/media/vest_images/veststyle/' . $fabric_id . '_style_' . $vstyle_id . '_bottom_' . $bottom . '_view_1.png');
                        exec('convert ' . $rootPath . '/pub/media/vest_images/veststyle/' . $fabric_id . '_style_' . $vstyle_id . '_bottom_' . $bottom . '_view_1.png ' . $veststyle_glow . ' -geometry +0+0 -composite ' . $rootPath . '/pub/media/vest_images/veststyle/' . $fabric_id . '_style_' . $vstyle_id . '_bottom_' . $bottom . '_view_1.png');
                    }

                    exec('composite -compose CopyOpacity ' . $backvest_mask . ' ' . $vestfabric_0 . ' ' . $rootPath . '/pub/media/vest_images/veststyle/' . $fabric_id . '_style_' . $vstyle_id . '_bottom_' . $bottom . '_view_2.png');
                    exec('convert ' . $rootPath . '/pub/media/vest_images/veststyle/' . $fabric_id . '_style_' . $vstyle_id . '_bottom_' . $bottom . '_view_2.png ' . $backvest_glow . ' -geometry +0+0 -composite ' . $rootPath . '/pub/media/vest_images/veststyle/' . $fabric_id . '_style_' . $vstyle_id . '_bottom_' . $bottom . '_view_2.png');
                }

                /* Create Vest style END */

                /* Vest lining and back collar START */

                $vest_lining_glow = $rootPath . '/pub/media/glow_mask/lining/vest_innerlining_glow.png';
                $vest_lining_mask = $rootPath . '/pub/media/glow_mask/lining/vest_innerlining_mask.png';

                $vest_inner_collar_glow = $rootPath . '/pub/media/glow_mask/lining/vest_inner_collar_glow.png';
                $vest_inner_collar_mask = $rootPath . '/pub/media/glow_mask/lining/vest_inner_collar_mask.png';


                exec('composite -compose CopyOpacity ' . $vest_lining_mask . ' ' . $vestfabric_0 . ' ' . $rootPath . '/pub/media/vest_images/vestlining/' . $fabric_id . '_vestlining_view_3.png');
                exec('convert ' . $rootPath . '/pub/media/vest_images/vestlining/' . $fabric_id . '_vestlining_view_3.png ' . $vest_lining_glow . ' -geometry +0+0 -composite ' . $rootPath . '/pub/media/vest_images/vestlining/' . $fabric_id . '_vestlining_view_3.png');

                exec('composite -compose CopyOpacity ' . $vest_inner_collar_mask . ' ' . $vestfabric_0 . ' ' . $rootPath . '/pub/media/vest_images/vestlining/' . $fabric_id . '_vestcollar_view_3.png');
                exec('convert ' . $rootPath . '/pub/media/vest_images/vestlining/' . $fabric_id . '_vestcollar_view_3.png ' . $vest_inner_collar_glow . ' -geometry +0+0 -composite ' . $rootPath . '/pub/media/vest_images/vestlining/' . $fabric_id . '_vestcollar_view_3.png');

                /* Vest lining and back collar END */

                /* vest lapel images START */
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
                $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
                $connection = $resource->getConnection();
//                $tableName = $resource->getTableName('employee'); //gives table name with prefix
                
                
                for ($i = 1; $i < 3; $i++) {
                   $sql = "SELECT * FROM `vest_vestlapel` WHERE `style`='".$i."'";
                   $lapel_data = $connection->fetchAll($sql);

                    foreach ($lapel_data as $lapel) {

                        $lapel_style_type = $lapel['style'];
                        $lapel_type = $lapel['lapel'];
                        $vest_glow = $rootPath . '/pub/media/' . $lapel['vest_vestlapelglowimage'];
                        $vest_mask = $rootPath . '/pub/media/' . $lapel['vest_vestlapelmaskimage'];

                        exec('composite -compose CopyOpacity ' . $vest_mask . ' ' . $fabric_0 .' '. $rootPath . '/pub/media/vest_images/vestlapel/' . $fabric_id . '_style_' . $lapel_style_type . '_lapel_' . $lapel_type . '_view_1.png');
                        exec('convert '.$rootPath . '/pub/media/vest_images/vestlapel/' . $fabric_id . '_style_' . $lapel_style_type . '_lapel_' . $lapel_type . '_view_1.png ' . $vest_glow . ' -geometry +0+0 -composite '.$rootPath . '/pub/media/vest_images/vestlapel/' . $fabric_id . '_style_' . $lapel_style_type . '_lapel_' . $lapel_type . '_view_1.png');
                    }
                }

                /* vest lapel images END */
                
                /* Vest pocket images START*/
                
                $veststyleModel = $this->_objectManager->create('Vest\Vestpocket\Model\Vestpocket');
                $vestpocket_collection = $veststyleModel->getCollection();
                foreach ($vestpocket_collection as $vestpocket) 
                {
                    $vestpocket_id = $vestpocket->getVestVestpocketId();
                    $vestpocket_glow = $rootPath . '/pub/media/' . $vestpocket->getVestVestpocketglowimage();
                    $vestpocket_mask = $rootPath . '/pub/media/' . $vestpocket->getVestVestpocketmaskimage();

                    if($vestpocket->getVestVestpocketglowimage() != '' && $vestpocket->getVestVestpocketmaskimage() != '') 
                    {
                        exec('composite -compose CopyOpacity ' . $vestpocket_mask . ' ' . $fabric_0 . ' '.$rootPath . '/pub/media/vest_images/vestpockets/' . $fabric_id . '_vestpockets_' . $vestpocket_id . '_view_1.png');
                        exec('convert '.$rootPath . '/pub/media/vest_images/vestpockets/' . $fabric_id . '_vestpockets_' . $vestpocket_id . '_view_1.png ' . $vestpocket_glow . ' -geometry +0+0 -composite '.$rootPath . '/pub/media/vest_images/vestpockets/' . $fabric_id . '_vestpockets_' . $vestpocket_id . '_view_1.png');
                    }
                    
                    
                    $vestpocket_ticket_glow = $rootPath . '/pub/media/' . $vestpocket->getVestVestpocketticketglowimage();
                    $vestpocket_ticket_mask = $rootPath . '/pub/media/' . $vestpocket->getVestVestpocketticketmaskimage();

                    if($vestpocket->getVestVestpocketticketglowimage() != '' && $vestpocket->getVestVestpocketticketmaskimage() != '') 
                    {
                        exec('composite -compose CopyOpacity ' . $vestpocket_ticket_mask . ' ' . $fabric_0 .' '. $rootPath . '/pub/media/vest_images/vestpockets/' . $fabric_id . '_ticketpockets_' . $vestpocket_id . '_view_1.png');
                        exec('convert '.$rootPath . '/pub/media/vest_images/vestpockets/' . $fabric_id . '_ticketpockets_' . $vestpocket_id . '_view_1.png ' . $vestpocket_ticket_glow . ' -geometry +0+0 -composite '.$rootPath . '/pub/media/vest_images/vestpockets/' . $fabric_id . '_ticketpockets_' . $vestpocket_id . '_view_1.png');
                    }
                }

                   /* Vest pocket images END*/
                
                /* Vest breast pocket START*/
                
                $vestbreastpocket_glow = $rootPath . '/pub/media/glow_mask/vestpocket/Vest_Breast-Pocket_Glow.png';
                $vestbreastpocket_mask = $rootPath . '/pub/media/glow_mask/vestpocket/Vest_Breast-Pocket_Mask.png';
                
                exec('composite -compose CopyOpacity ' . $vestbreastpocket_mask . ' ' . $fabric_0 .' '.$rootPath . '/pub/media/vest_images/vestpockets/' . $fabric_id . '_breastpocket_view_1.png');
                exec('convert '.$rootPath . '/pub/media/vest_images/vestpockets/' . $fabric_id . '_breastpocket_view_1.png ' . $vestbreastpocket_glow . ' -geometry +0+0 -composite '.$rootPath . '/pub/media/vest_images/vestpockets/' . $fabric_id . '_breastpocket_view_1.png');
                    /* Vest breast pocket END*/

                    /* Create Pant cuff images START*/

                $collection = $this->_objectManager->create('PantDesign\PantCuff\Model\PantCuff');
                $pantcuff= $collection->getCollection();
                foreach($pantcuff as $pant)
                {
                    // echo "<pre>";
                    // print_r($pant->getData());
                     // echo "<pre>";
                 $pantcuff_id = $pant->getPantdesignPantcuffId();
                 $pantcuff_glow = $rootPath.'/pub/media/' . $pant->getPantdesignPlainpantcuffimage();
                     $pantcuff_mask = $rootPath.'/pub/media/' . $pant->getPantdesignMaskimage();

                    if ($pant->getPantdesignMaskimage() != '' && $pant->getPantdesignPlainpantcuffimage() != '') {

                        exec('composite -compose CopyOpacity ' . $pantcuff_mask . ' ' . $fabric_0 .' '. $rootPath.'/pub/media/pant_images/pantcuff/' . $fabric_id . '_pantcuff_' . $pantcuff_id . '_view_1.png');
                        exec('convert media/pant_images/pantcuff/' . $fabric_id . '_pantcuff_' . $pantcuff_id . '_view_1.png ' . $pantcuff_glow . ' -geometry +0+0 -composite '.$rootPath.'/media/pant_images/pantcuff/' . $fabric_id . '_pantcuff_' . $pantcuff_id . '_view_1.png');
                    }
                    
                    
                    $back_pantcuff_glow = $rootPath.'/pub/media/' . $pant->getPantdesignBackglowimage();
                    $back_pantcuff_mask = $rootPath.'/pub/media/' . $pant->getPantdesignBackmaskimage();

                    if ($pant->getPantdesignBackglowimage() != '' && $pant->getPantdesignBackmaskimage() != '') {
                        // echo 'composite -compose CopyOpacity ' . $back_pantcuff_mask . ' ' . $fabric_0 .' '.$rootPath.'/pub/media/pant_images/pantcuff/' . $fabric_id . '_pantcuff_' . $pantcuff_id . '_view_2.png';die;
                        exec('composite -compose CopyOpacity ' . $back_pantcuff_mask . ' ' . $fabric_0 .' '.$rootPath.'/pub/media/pant_images/pantcuff/' . $fabric_id . '_pantcuff_' . $pantcuff_id . '_view_2.png');
                        exec('convert media/pant_images/pantcuff/' . $fabric_id . '_pantcuff_' . $pantcuff_id . '_view_2.png ' . $back_pantcuff_glow . ' -geometry +0+0 -composite media/pant_images/pantcuff/' . $fabric_id . '_pantcuff_' . $pantcuff_id . '_view_2.png');
                    }
                    
                }

                 /* Create Pant cuff images END*/


                      /* Create Pant pleats images START*/

        $pantpleats_collection = $this->_objectManager->create('PantDesign\PantPleats\Model\PantPleats');     $pantpleats_collection= $pantpleats_collection->getCollection();
                //$pantpleats_collection = Mage::getModel('pantpleats/pantpleats')->getCollection();

                foreach ($pantpleats_collection as $pantpleats) {
                    // echo "<pre>";
                    // print_r($pantpleats->getData());
                    $pantpleats_id = $pantpleats->getPantdesignPantpleatsId();
            $pantpleats_glow = $rootPath.'/pub/media/' .$pantpleats->getPantdesignPlainpantpleatsimage();//glow image
                    $pantpleats_mask = $rootPath.'/pub/media/blank.png';

                    if ($pantpleats->getPantdesignPlainpantpleatsimage() != '' && $pantpleats_mask != '') {
                         // echo 'composite -compose CopyOpacity ' . $pantpleats_mask . ' ' . $fabric_0 . ' '. $rootPath.'/pub/media/pant_images/pantpleats/' . $fabric_id . '_pantpleats_' . $pantpleats_id . '_view_1.png';die;
                        exec('composite -compose CopyOpacity ' . $pantpleats_mask . ' ' . $fabric_0 . ' '. $rootPath.'/pub/media/pant_images/pantpleats/' . $fabric_id . '_pantpleats_' . $pantpleats_id . '_view_1.png');
                        exec('convert media/pant_images/pantpleats/' . $fabric_id . '_pantpleats_' . $pantpleats_id . '_view_1.png ' . $pantpleats_glow . ' -geometry +0+0 -composite media/pant_images/pantpleats/' . $fabric_id . '_pantpleats_' . $pantpleats_id . '_view_1.png');
                    }
                }
 /* Create Pant pleats images END*/

                /* Create Pant Fit images START*/
              $pantfit_collection = $this->_objectManager->create('PantDesign\PantFit\Model\PantFit');     
              $pantfit_collection= $pantfit_collection->getCollection();
               

                foreach ($pantfit_collection as $pantfit) {
                 
                   $pantfit_id = $pantfit->getPantdesignPantfitId();
                    $pantfit_glow = $rootPath.'/pub/media/' . $pantfit->getPantdesignPlainpantfitimage();
                    $pantfit_mask = $rootPath.'/pub/media/' . $pantfit->getPantdesignMaskimage();

                    if ($pantfit_glow != '' && $pantfit_mask != '') {
                       
                        exec('composite -compose CopyOpacity ' . $pantfit_mask . ' ' . $fabric_0 . ' '. $rootPath.'/pub/media/pant_images/pantfit/' . $fabric_id . '_pantfit_' . $pantfit_id . '_view_1.png');
                        exec('convert media/pant_images/pantfit/' . $fabric_id . '_pantfit_' . $pantfit_id . '_view_1.png ' . $pantfit_glow . ' -geometry +0+0 -composite media/pant_images/pantfit/' . $fabric_id . '_pantfit_' . $pantfit_id . '_view_1.png');
                    }

                    $pantfit_back_glow = $rootPath.'/pub/media/' . $pantfit->getPantdesignBackglowimage();
                    $pantfit_back_mask = $rootPath.'/pub/media/' . $pantfit->getPantdesignBackmaskimage();

                    if ($pantfit_back_glow != '' && $pantfit_back_mask != '') {
                     
                        exec('composite -compose CopyOpacity ' . $pantfit_back_mask . ' ' . $fabric_0 . ' '. $rootPath.'/pub/media/pant_images/pantfit/' . $fabric_id . '_pantfit_' . $pantfit_id . '_view_2.png');
                        exec('convert media/pant_images/pantfit/' . $fabric_id . '_pantfit_' . $pantfit_id . '_view_2.png ' . $pantfit_back_glow . ' -geometry +0+0 -composite media/pant_images/pantfit/' . $fabric_id . '_pantfit_' . $pantfit_id . '_view_2.png');
                    }
                } 
                /* Create Pant Fit images END*/

//                custom code 23/08/2017 END

                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['suit_fabric_id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the suit_fabric.'));
            }

            $this->dataPersistor->set('suit_fabric', $data);
            return $resultRedirect->setPath('*/*/edit', ['suit_fabric_id' => $this->getRequest()->getParam('suit_fabric_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }

}
