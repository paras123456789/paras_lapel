<?php
/**
* @author Dhirajkumar Deore    
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/

namespace Suit\Lapel\Model\Lapel;

use Suit\Lapel\Model\ResourceModel\Lapel\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;

/**
 * Class DataProvider
 */
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider {

    /**
     * @var \Magento\Cms\Model\ResourceModel\Block\Collection
     */
    protected $collection;

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;
    public $_storeManager;

    /**
     * @var array
     */
    protected $loadedData;

    /**
     * Constructor
     *
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $blockCollectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
    $name, $primaryFieldName, $requestFieldName, CollectionFactory $blockCollectionFactory, DataPersistorInterface $dataPersistor, \Magento\Store\Model\StoreManagerInterface $storeManager, array $meta = [], array $data = []
    ) {
        $this->collection = $blockCollectionFactory->create();
        $this->_storeManager = $storeManager;
        $this->dataPersistor = $dataPersistor;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData() {
        $temp=[];
        $tempthread=[];
        $baseurl = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        /** @var \Magento\Cms\Model\Block $block */
        foreach ($items as $block) {
            $this->loadedData[$block->getId()] = $block->getData();


            $temp = $block->getData();
            $img = [];
            $img[0]['name'] = $temp['suit_lapelimage'];
            $img[0]['url'] = $baseurl . $temp['suit_lapelimage'];
            $temp['suit_lapelimage'] = $img;

            
            $imgthread = [];
            $imgthread[0]['name'] = $temp['suit_lapelthreadimage'];
            $imgthread[0]['url'] = $baseurl . $temp['suit_lapelthreadimage'];
            $temp['suit_lapelthreadimage'] = $imgthread;
            
            $lower_left_glow_image = [];
            $lower_left_glow_image[0]['name'] = $temp['suit_lowerleftglow'];
            $lower_left_glow_image[0]['url'] = $baseurl . $temp['suit_lowerleftglow'];
            $temp['suit_lowerleftglow'] = $lower_left_glow_image;
            
            $lower_left_mask_image = [];
            $lower_left_mask_image[0]['name'] = $temp['suit_lowerleftmask'];
            $lower_left_mask_image[0]['url'] = $baseurl . $temp['suit_lowerleftmask'];
            $temp['suit_lowerleftmask'] = $lower_left_mask_image;
            
            $lower_right_glow_image = [];
            $lower_right_glow_image[0]['name'] = $temp['suit_lowerrightglow'];
            $lower_right_glow_image[0]['url'] = $baseurl . $temp['suit_lowerrightglow'];
            $temp['suit_lowerrightglow'] = $lower_right_glow_image;
            
            $lower_right_mask_image = [];
            $lower_right_mask_image[0]['name'] = $temp['suit_lowerrightmask'];
            $lower_right_mask_image[0]['url'] = $baseurl . $temp['suit_lowerrightmask'];
            $temp['suit_lowerrightmask'] = $lower_right_mask_image;
            
            $upper_left_glow_image = [];
            $upper_left_glow_image[0]['name'] = $temp['suit_upperleftglow'];
            $upper_left_glow_image[0]['url'] = $baseurl . $temp['suit_upperleftglow'];
            $temp['suit_upperleftglow'] = $upper_left_glow_image;
            
            $upper_left_mask_image = [];
            $upper_left_mask_image[0]['name'] = $temp['suit_upperleftmask'];
            $upper_left_mask_image[0]['url'] = $baseurl . $temp['suit_upperleftmask'];
            $temp['suit_upperleftmask'] = $upper_left_mask_image;
            
            $upper_right_glow_image = [];
            $upper_right_glow_image[0]['name'] = $temp['suit_upperrightglow'];
            $upper_right_glow_image[0]['url'] = $baseurl . $temp['suit_upperrightglow'];
            $temp['suit_upperrightglow'] = $upper_right_glow_image;
            
            $upper_right_mask_image = [];
            $upper_right_mask_image[0]['name'] = $temp['suit_upperrightmask'];
            $upper_right_mask_image[0]['url'] = $baseurl . $temp['suit_upperrightmask'];
            $temp['suit_upperrightmask'] = $upper_right_mask_image;
        }

        $data = $this->dataPersistor->get('suit_lapel');

        if (!empty($data)) {
            $block = $this->collection->getNewEmptyItem();
            $block->setData($data);

            $this->loadedData[$block->getId()] = $block->getData();

            $this->dataPersistor->clear('suit_lapel');
        }

        if (empty($this->loadedData)) {
            return $this->loadedData;
        } else {
            
            if ($block->getData('suit_lapelimage') != null) {
                $t2[$block->getId()] = $temp;
                return $t2;
            } else {
                return $this->loadedData;
            }
            
            if ($block->getData('suit_lapelthreadimage') != null) {
                $t2thread[$block->getId()] = $temp;
                return $t2thread;
            } else {
                return $this->loadedData;
            }
            
            if ($block->getData('suit_lowerleftglow') != null) {
                $t2thread[$block->getId()] = $temp;
                return $t2thread;
            } else {
                return $this->loadedData;
            }
            
            if ($block->getData('suit_lowerleftmask') != null) {
                $t2thread[$block->getId()] = $temp;
                return $t2thread;
            } else {
                return $this->loadedData;
            }
            
            if ($block->getData('suit_lowerrightglow') != null) {
                $t2thread[$block->getId()] = $temp;
                return $t2thread;
            } else {
                return $this->loadedData;
            }
            
            if ($block->getData('suit_lowerrightmask') != null) {
                $t2thread[$block->getId()] = $temp;
                return $t2thread;
            } else {
                return $this->loadedData;
            }
            
            if ($block->getData('suit_upperleftglow') != null) {
                $t2thread[$block->getId()] = $temp;
                return $t2thread;
            } else {
                return $this->loadedData;
            }
            
            if ($block->getData('suit_upperleftmask') != null) {
                $t2thread[$block->getId()] = $temp;
                return $t2thread;
            } else {
                return $this->loadedData;
            }
            
            if ($block->getData('suit_upperrightglow') != null) {
                $t2thread[$block->getId()] = $temp;
                return $t2thread;
            } else {
                return $this->loadedData;
            }
            
            if ($block->getData('suit_upperrightmask') != null) {
                $t2thread[$block->getId()] = $temp;
                return $t2thread;
            } else {
                return $this->loadedData;
            }
            
        }
    }

}
