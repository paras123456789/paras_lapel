<?php
/**
* @author Dhirajkumar Deore
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Suit\Custom\Controller\Adminhtml\Index;

use Magento\Backend\App\Action\Context;
use Magento\Backend\App\Action;
use Suit\Custom\Model\Custom;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\TestFramework\Inspection\Exception;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\RequestInterface;

//use Magento\Framework\Stdlib\DateTime\DateTime;
//use Magento\Ui\Component\MassAction\Filter;
//use FME\News\Model\ResourceModel\Test\CollectionFactory;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;
    protected $scopeConfig;

    protected $_escaper;
    protected $inlineTranslation;
    protected $_dateFactory;
    //protected $_modelNewsFactory;
  //  protected $collectionFactory;
   //  protected $filter;
    /**
     * @param Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param DataPersistorInterface $dataPersistor
     */
    public function __construct(
        Context $context,
        DataPersistorInterface $dataPersistor,
        \Magento\Framework\Escaper $escaper,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Stdlib\DateTime\DateTimeFactory $dateFactory
    ) {
       // $this->filter = $filter;
       // $this->collectionFactory = $collectionFactory;
        $this->dataPersistor = $dataPersistor;
         $this->scopeConfig = $scopeConfig;
         $this->_escaper = $escaper;
        $this->_dateFactory = $dateFactory;
         $this->inlineTranslation = $inlineTranslation;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {

        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();

        if ($data) {

            $id = $this->getRequest()->getParam('suit_custom_id');

            if (isset($data['status']) && $data['status'] === 'true') {
                $data['status'] = Block::STATUS_ENABLED;
            }
            if (empty($data['suit_custom_id'])) {
                $data['suit_custom_id'] = null;
            }


            /** @var \Magento\Cms\Model\Block $model */
            $model = $this->_objectManager->create('Suit\Custom\Model\Custom')->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addError(__('This suit_custom no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }


            if (isset($data['suit_customimage'][0]['name']) && isset($data['suit_customimage'][0]['tmp_name'])) {
                $data['suit_customimage'] ='/suit_custom/'.$data['suit_customimage'][0]['name'];
            } elseif (isset($data['suit_customimage'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['suit_customimage'] =$data['suit_customimage'][0]['name'];
            } else {
                $data['suit_customimage'] = null;
            }


            if (isset($data['suit_customthreadimage'][0]['name']) && isset($data['suit_customthreadimage'][0]['tmp_name'])) {
                $data['suit_customthreadimage'] ='/suit_custom/'.$data['suit_customthreadimage'][0]['name'];
            } elseif (isset($data['suit_customthreadimage'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['suit_customthreadimage'] =$data['suit_customthreadimage'][0]['name'];
            } else {
                $data['suit_customthreadimage'] = null;
            }

            //
            // if (isset($data['suit_lowerleftglow'][0]['name']) && isset($data['suit_lowerleftglow'][0]['tmp_name'])) {
            //     $data['suit_lowerleftglow'] ='/suit_custom/'.$data['suit_lowerleftglow'][0]['name'];
            // } elseif (isset($data['suit_lowerleftglow'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
            //     $data['suit_lowerleftglow'] =$data['suit_lowerleftglow'][0]['name'];
            // } else {
            //     $data['suit_lowerleftglow'] = null;
            // }
            //
            //
            // if (isset($data['suit_lowerleftmask'][0]['name']) && isset($data['suit_lowerleftmask'][0]['tmp_name'])) {
            //     $data['suit_lowerleftmask'] ='/suit_custom/'.$data['suit_lowerleftmask'][0]['name'];
            // } elseif (isset($data['suit_lowerleftmask'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
            //     $data['suit_lowerleftmask'] =$data['suit_lowerleftmask'][0]['name'];
            // } else {
            //     $data['suit_lowerleftmask'] = null;
            // }
            //
            //
            // if (isset($data['suit_lowerrightglow'][0]['name']) && isset($data['suit_lowerrightglow'][0]['tmp_name'])) {
            //     $data['suit_lowerrightglow'] ='/suit_custom/'.$data['suit_lowerrightglow'][0]['name'];
            // } elseif (isset($data['suit_lowerrightglow'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
            //     $data['suit_lowerrightglow'] =$data['suit_lowerrightglow'][0]['name'];
            // } else {
            //     $data['suit_lowerrightglow'] = null;
            // }
            //
            //
            // if (isset($data['suit_lowerrightmask'][0]['name']) && isset($data['suit_lowerrightmask'][0]['tmp_name'])) {
            //     $data['suit_lowerrightmask'] ='/suit_custom/'.$data['suit_lowerrightmask'][0]['name'];
            // } elseif (isset($data['suit_lowerrightmask'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
            //     $data['suit_lowerrightmask'] =$data['suit_lowerrightmask'][0]['name'];
            // } else {
            //     $data['suit_lowerrightmask'] = null;
            // }
            //
            //
            // if (isset($data['suit_upperleftglow'][0]['name']) && isset($data['suit_upperleftglow'][0]['tmp_name'])) {
            //     $data['suit_upperleftglow'] ='/suit_custom/'.$data['suit_upperleftglow'][0]['name'];
            // } elseif (isset($data['suit_upperleftglow'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
            //     $data['suit_upperleftglow'] =$data['suit_upperleftglow'][0]['name'];
            // } else {
            //     $data['suit_upperleftglow'] = null;
            // }
            //
            //
            // if (isset($data['suit_upperleftmask'][0]['name']) && isset($data['suit_upperleftmask'][0]['tmp_name'])) {
            //     $data['suit_upperleftmask'] ='/suit_custom/'.$data['suit_upperleftmask'][0]['name'];
            // } elseif (isset($data['suit_upperleftmask'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
            //     $data['suit_upperleftmask'] =$data['suit_upperleftmask'][0]['name'];
            // } else {
            //     $data['suit_upperleftmask'] = null;
            // }
            //
            //
            // if (isset($data['suit_upperrightglow'][0]['name']) && isset($data['suit_upperrightglow'][0]['tmp_name'])) {
            //     $data['suit_upperrightglow'] ='/suit_custom/'.$data['suit_upperrightglow'][0]['name'];
            // } elseif (isset($data['suit_upperrightglow'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
            //     $data['suit_upperrightglow'] =$data['suit_upperrightglow'][0]['name'];
            // } else {
            //     $data['suit_upperrightglow'] = null;
            // }
            //
            //
            // if (isset($data['suit_upperrightmask'][0]['name']) && isset($data['suit_upperrightmask'][0]['tmp_name'])) {
            //     $data['suit_upperrightmask'] ='/suit_custom/'.$data['suit_upperrightmask'][0]['name'];
            // } elseif (isset($data['suit_upperrightmask'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
            //     $data['suit_upperrightmask'] =$data['suit_upperrightmask'][0]['name'];
            // } else {
            //     $data['suit_upperrightmask'] = null;
            // }

            if (!isset($data['suit_customimage2'][0]['name']) && isset($data['suit_customimage2'][0]['tmp_name'])) {

                $data['suit_customimage2'] ='/suit_custom/'.$data['suit_customimage2'][0]['name'];
            } elseif (isset($data['suit_customimage2'][0]['name']) && !isset($data['image'][0]['tmp_name'])) {
                $data['suit_customimage2'] =$data['suit_customimage2'][0]['name'];
            } else {
                $data['suit_customimage2'] = null;
            }



            $model->setData($data);


            $this->inlineTranslation->suspend();
            try {
                    //////////////////// email
                $model->save();
                $this->messageManager->addSuccess(__('suit_custom Saved successfully'));
                $this->dataPersistor->clear('suit_custom');

                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['suit_custom_id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the suit_custom.'));
                print_r($e);
            }

            $this->dataPersistor->set('suit_custom', $data);
            return $resultRedirect->setPath('*/*/edit', ['suit_custom_id' => $this->getRequest()->getParam('suit_custom_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }
}
