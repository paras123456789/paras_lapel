
# Magento 2 Sample Module By CedCommerce 


**Magento 2 Sample Module**, a Magento 2.0 module for creating frontend controller,frontend view and backend grid. 



##If you need customized module according to your need, then visit below link
   <a href="http://cedcommerce.com/magento-2-module-creator/">http://cedcommerce.com/magento-2-module-creator/</a>

## Authors, contributors and maintainers

![](images/Logo.png)



## License

[GPL v3](LICENSE.txt)