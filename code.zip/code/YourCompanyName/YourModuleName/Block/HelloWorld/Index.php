<?php
/**
 * Copyright © 2015 YourCompanyName . All rights reserved.
 */
namespace YourCompanyName\YourModuleName\Block\HelloWorld;
use YourCompanyName\YourModuleName\Block\BaseBlock;
class Index extends BaseBlock
{

	
}
