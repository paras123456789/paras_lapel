<?php

namespace Mageplaza\HelloWorld\Plugin;

class ExamplePlugin2
{


  public function beforeSetName(\Mageplaza\HelloWorld\Block\Index $subject, $name)
  { 
    $name = $name . " name from plugin";
  echo __METHOD__ . "</br>";die;

    return [$name];
  }


  // public function afterGetTitle(\Mageplaza\HelloWorld\Controller\Index\Example $subject, $result)
  // {
  //
  //   // echo __METHOD__ . "</br>";
  //
  //   return '<h1>'. $result . 'Mageplaza.com' .'</h1>';
  //
  // }
  //
  //
  // public function aroundGetTitle(\Mageplaza\HelloWorld\Controller\Index\Example $subject, callable $proceed)
	// {
  //
	// 	// echo __METHOD__ . " - Before proceed() </br>";
	// 	 $result = $proceed();
	// 	// echo __METHOD__ . " - After proceed() </br>";
  //
  //
	// 	return $result;
	// }


}
