<?php
namespace Mageplaza\HelloWorld\Block;
class Index extends \Magento\Framework\View\Element\Template
{
  protected $title;
  protected $name;

  public function __construct(
    \Magento\Framework\View\Element\Template\Context $context,
    \Mageplaza\HelloWorld\Model\CustomerFactory $postFactory)
  {
    $this->_postFactory = $postFactory;
    parent::__construct($context);
  }

  public function getCustomerCollection(){
  $post = $this->_postFactory->create();
  return $post->getCollection();
}


// these methods for the block plugins..
public function setName($name)
{
  echo "in block ";
  return $this->name = $name;
}

public function getName()
{
  return $this->name;
}


}
