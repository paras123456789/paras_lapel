<?php

namespace Mageplaza\HelloWorld\Observer;

class ChangeDisplayText2 implements \Magento\Framework\Event\ObserverInterface
{
	public function execute(\Magento\Framework\Event\Observer $observer)
	{
		$displayText = $observer->getData();
		echo $displayText->getTxt() . " - 2 Event </br>";
		$displayText->setTxt('Execute event 2 successfully.');

		return $this;
	}
}
