<?php

namespace Magestore\Company\Controller\Adminhtml\Staff;


class Index extends \Magestore\Company\Controller\Adminhtml\Staff
{
    
    public function execute()
    {

        $resultPage = $this->_resultPageFactory->create();

        return $resultPage;
    }
}
