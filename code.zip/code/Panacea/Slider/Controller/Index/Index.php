<?php 
    namespace Panacea\Slider\Controller\Index; 
    use Magento\Framework\App\Action\Action;
    use Magento\Framework\App\Action\Context;
    use Panacea\Slider\Model\ResourceModel\Author\CollectionFactory as AuthorCollectionFactory;
   // use Panacea\Slidercat\Model\ResourceModel\Author\CollectionFactory as AuthorcatCollectionFactory;

    class Index extends \Magento\Framework\App\Action\Action 
    {
        protected $resultJsonFactory;
        protected $authorCollectionFactory;
       // protected $authorcatCollectionFactory;
    
        public function __construct(\Magento\Framework\App\Action\Context $context,AuthorCollectionFactory $authorCollectionFactory,\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory)     
        {
            $this->resultJsonFactory = $resultJsonFactory;
            $this->authorCollectionFactory = $authorCollectionFactory;
           // $this->authorcatCollectionFactory = $authorcatCollectionFactory;
            parent::__construct($context);
        }

        public function execute()
        {      
            
            return $this->resultPageFactory->create();
        }
    }
?>
