<?php
/**
 * Panacea_Slider extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the MIT License
 * that is bundled with this package in the file LICENSE
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/mit-license.php
 *
 * @category  Panacea
 * @package   Panacea_Slider
 * @copyright 2016 Marius Strajeru
 * @license   http://opensource.org/licenses/mit-license.php MIT License
 * @author    Marius Strajeru
 */
namespace Panacea\Slider\Controller\Adminhtml\Author;

use Panacea\Slider\Controller\Adminhtml\Author;
use Panacea\Slider\Controller\RegistryConstants;

class Edit extends Author
{
    /**
     * Initialize current author and set it in the registry.
     *
     * @return int
     */
    protected function _initAuthor()
    {
        $authorId = $this->getRequest()->getParam('slider_id');
        $this->coreRegistry->register(RegistryConstants::CURRENT_SLIDER_ID, $authorId);

        return $authorId;
    }

    /**
     * Edit or create author
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $authorId = $this->_initAuthor();

        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Panacea_Slider::author');
        $resultPage->getConfig()->getTitle()->prepend(__('Sliders'));
        $resultPage->addBreadcrumb(__('Sliders'), __('Sliders'));
        $resultPage->addBreadcrumb(__('Sliders'), __('Sliders'), $this->getUrl('panacea_slider/author'));

        if ($authorId === null) {
            $resultPage->addBreadcrumb(__('New Slider'), __('New Slider'));
            $resultPage->getConfig()->getTitle()->prepend(__('New Slider'));
        } else {
            $resultPage->addBreadcrumb(__('Edit Slider'), __('Edit Slider'));
            $resultPage->getConfig()->getTitle()->prepend(
                $this->authorRepository->getById($authorId)->getName()
            );
        }
        return $resultPage;
    }
}
