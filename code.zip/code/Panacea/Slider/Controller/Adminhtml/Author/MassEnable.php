<?php
/**
 * Panacea_Slider extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the MIT License
 * that is bundled with this package in the file LICENSE
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/mit-license.php
 *
 * @category  Panacea
 * @package   Panacea_Slider
 * @copyright 2016 Marius Strajeru
 * @license   http://opensource.org/licenses/mit-license.php MIT License
 * @author    Marius Strajeru
 */
namespace Panacea\Slider\Controller\Adminhtml\Author;

class MassEnable extends MassDisable
{
    /**
     * @var bool
     */
    protected $isActive = true;
}
