<?php
/**
 * Panacea_Slider extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the MIT License
 * that is bundled with this package in the file LICENSE
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/mit-license.php
 *
 * @category  Panacea
 * @package   Panacea_Slider
 * @copyright 2016 Marius Strajeru
 * @license   http://opensource.org/licenses/mit-license.php MIT License
 * @author    Marius Strajeru
 */
namespace Panacea\Slider\Controller\Adminhtml\Author;

use \Panacea\Slider\Controller\Adminhtml\Author as AuthorController;

class Index extends AuthorController
{
    /**
     * Authors list.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Panacea_Slider::author');
        $resultPage->getConfig()->getTitle()->prepend(__('Sliders'));
        $resultPage->addBreadcrumb(__('Slider'), __('Slider'));
        $resultPage->addBreadcrumb(__('Sliders'), __('Sliders'));
        return $resultPage;
    }
}
