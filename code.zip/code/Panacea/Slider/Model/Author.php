<?php
/**
 * Panacea_Slider extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the MIT License
 * that is bundled with this package in the file LICENSE
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/mit-license.php
 *
 * @category  Panacea
 * @package   Panacea_Slider
 * @copyright 2016 Marius Strajeru
 * @license   http://opensource.org/licenses/mit-license.php MIT License
 * @author    Marius Strajeru
 */
namespace Panacea\Slider\Model;

use Magento\Framework\Data\Collection\AbstractDb;
use Magento\Framework\Data\Collection\Db;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Filter\FilterManager;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\Context;
use Magento\Framework\Model\ResourceModel\AbstractResource;
use Magento\Framework\Registry;
use Panacea\Slider\Api\Data\AuthorInterface;
use Panacea\Slider\Model\Author\Url;
use Panacea\Slider\Model\ResourceModel\Author as AuthorResourceModel;
use Panacea\Slider\Model\Routing\RoutableInterface;
use Panacea\Slider\Model\Source\AbstractSource;


/**
 * @method AuthorResourceModel _getResource()
 * @method AuthorResourceModel getResource()
 */
class Author extends AbstractModel implements AuthorInterface, RoutableInterface
{
    /**
     * @var int
     */
    const STATUS_ENABLED = 1;
    /**
     * @var int
     */
    const STATUS_DISABLED = 0;
    /**
     * @var Url
     */
    protected $urlModel;
    /**
     * cache tag
     *
     * @var string
     */
    const CACHE_TAG = 'slider';

    /**
     * cache tag
     *
     * @var string
     */
    protected $_cacheTag = 'slider';

    /**
     * Prefix of model events names
     *
     * @var string
     */
    protected $_eventPrefix = 'slider';

    /**
     * filter model
     *
     * @var \Magento\Framework\Filter\FilterManager
     */
    protected $filter;

    /**
     * @var UploaderPool
     */
    protected $uploaderPool;

    /**
     * @var \Panacea\Slider\Model\Output
     */
    protected $outputProcessor;

    /**
     * @var AbstractSource[]
     */
    protected $optionProviders;

    /**
     * @param Context $context
     * @param Registry $registry
     * @param Output $outputProcessor
     * @param UploaderPool $uploaderPool
     * @param FilterManager $filter
     * @param Url $urlModel
     * @param array $optionProviders
     * @param array $data
     * @param AbstractResource|null $resource
     * @param AbstractDb|null $resourceCollection
     */
    public function __construct(
        Context $context,
        Registry $registry,
        Output $outputProcessor,
        UploaderPool $uploaderPool,
        FilterManager $filter,
        Url $urlModel,
        array $optionProviders = [],
        array $data = [],
        AbstractResource $resource = null,
        AbstractDb $resourceCollection = null
    )
    {
        $this->outputProcessor = $outputProcessor;
        $this->uploaderPool    = $uploaderPool;
        $this->filter          = $filter;
        $this->urlModel        = $urlModel;
        $this->optionProviders = $optionProviders;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(AuthorResourceModel::class);
    }

    /**
     * Get in rss
     *
     * @return bool|int
     */
    public function getInRss()
    {
        return $this->getData(AuthorInterface::IN_RSS);
    }


   
    /**
     * set slider_name
     *
     * @param $sliderName
     * @return AuthorInterface
     */
    public function setSliderName($sliderName)
    {
        return $this->setData(AuthorInterface::SLIDER_NAME, $sliderName);
    }
    
    
   

    /**
     * Set in rss
     *
     * @param $inRss
     * @return AuthorInterface
     */
    public function setInRss($inRss)
    {
        return $this->setData(AuthorInterface::IN_RSS, $inRss);
    }

    /**
     * Set biography
     *
     * @param $biography
     * @return AuthorInterface
     */
    public function setBiography($biography)
    {
        return $this->setData(AuthorInterface::BIOGRAPHY, $biography);
    }



    /**
     * Get slider_name
     *
     * @return string
     */
    public function getSliderName()
    {
        return $this->getData(AuthorInterface::SLIDER_NAME);
    }
    
    
    

    /**
     * Get url key
     *
     * @return string
     */
    public function getUrlKey()
    {
        return $this->getData(AuthorInterface::URL_KEY);
    }

    /**
     * Get is active
     *
     * @return bool|int
     */
    public function getIsActive()
    {
        return $this->getData(AuthorInterface::IS_ACTIVE);
    }

    /**
     * Get biography
     *
     * @return string
     */
    public function getBiography()
    {
        return $this->getData(AuthorInterface::BIOGRAPHY);
    }

    /**
     * @return mixed
     */
    public function getProcessedBiography()
    {
        return $this->outputProcessor->filterOutput($this->getBiography());
    }

    
    /**
     * Get avatar
     *
     * @return string
     */
    public function getAvatar()
    {
        return $this->getData(AuthorInterface::AVATAR);
    }

    /**
     * @return bool|string
     * @throws LocalizedException
     */
    public function getAvatarUrl()
    {
        $url = false;
        $avatar = $this->getAvatar();
        if ($avatar) {
            if (is_string($avatar)) {
                $uploader = $this->uploaderPool->getUploader('image');
                $url = $uploader->getBaseUrl().$uploader->getBasePath().$avatar;
            } else {
                throw new LocalizedException(
                    __('Something went wrong while getting the avatar url.')
                );
            }
        }
        return $url;
    }

    
    
    /**
     * Get created at
     *
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->getData(AuthorInterface::CREATED_AT);
    }

    /**
     * Get updated at
     *
     * @return string
     */
    public function getUpdatedAt()
    {
        return $this->getData(AuthorInterface::UPDATED_AT);
    }

    /**
     * set url key
     *
     * @param $urlKey
     * @return AuthorInterface
     */
    public function setUrlKey($urlKey)
    {
        return $this->setData(AuthorInterface::URL_KEY, $urlKey);
    }

    /**
     * Set is active
     *
     * @param $isActive
     * @return AuthorInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(AuthorInterface::IS_ACTIVE, $isActive);
    }

    /**
     * set avatar
     *
     * @param $avatar
     * @return AuthorInterface
     */
    public function setAvatar($avatar)
    {
        return $this->setData(AuthorInterface::AVATAR, $avatar);
    }

   
    /**
     * set created at
     *
     * @param $createdAt
     * @return AuthorInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(AuthorInterface::CREATED_AT, $createdAt);
    }

    /**
     * set updated at
     *
     * @param $updatedAt
     * @return AuthorInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(AuthorInterface::UPDATED_AT, $updatedAt);
    }


    /**
     * Check if author url key exists
     * return author id if author exists
     *
     * @param string $urlKey
     * @param int $storeId
     * @return int
     */
    public function checkUrlKey($urlKey, $storeId)
    {
        return $this->_getResource()->checkUrlKey($urlKey, $storeId);
    }

    /**
     * Get identities
     *
     * @return array
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * @param $storeId
     * @return AuthorInterface
     */
    public function setStoreId($storeId)
    {
        $this->setData(AuthorInterface::STORE_ID, $storeId);
        return $this;
    }

    /**
     * @return array
     */
    public function getStoreId()
    {
        return $this->getData(AuthorInterface::STORE_ID);
    }

    


    /**
     * sanitize the url key
     *
     * @param $string
     * @return string
     */
    public function formatUrlKey($string)
    {
        return $this->filter->translitUrl($string);
    }

    /**
     * @return mixed
     */
    public function getAuthorUrl()
    {
        return $this->urlModel->getAuthorUrl($this);
    }

    /**
     * @return bool
     */
    public function isActive()
    {
        return (bool)$this->getIsActive();
    }

    /**
     * @param $attribute
     * @return string
     */
    public function getAttributeText($attribute)
    {
        if (!isset($this->optionProviders[$attribute])) {
            return '';
        }
        if (!($this->optionProviders[$attribute] instanceof AbstractSource)) {
            return '';
        }
        return $this->optionProviders[$attribute]->getOptionText($this->getData($attribute));
    }
}
