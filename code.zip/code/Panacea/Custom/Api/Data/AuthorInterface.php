<?php
/**
 * Panacea_Custom extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the MIT License
 * that is bundled with this package in the file LICENSE
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/mit-license.php
 *
 * @category  Panacea
 * @package   Panacea_Custom
 * @copyright 2016 Marius Strajeru
 * @license   http://opensource.org/licenses/mit-license.php MIT License
 * @author    Marius Strajeru
 */
namespace Panacea\Custom\Api\Data;

/**
 * @api
 */
interface AuthorInterface
{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case
     */
    const SLIDER_ID         = 'custom_id';
    const SLIDER_NAME       = 'custom_name';
    const URL_KEY           = 'url_key';
    const IS_ACTIVE         = 'is_active';
    const IN_RSS            = 'in_rss';
    const BIOGRAPHY         = 'biography';
    const AVATAR            = 'avatar';
    const CREATED_AT        = 'created_at';
    const UPDATED_AT        = 'updated_at';
    const STORE_ID          = 'store_id';
    // const MOBILE            = 'custom_mobile';
    // const GENDER            = 'gender';


    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId();

    /**
     * Get custom_name
     *
     * @return string
     */
    public function getCustomName();


    /**
     * Get url key
     *
     * @return string
     */
    public function getUrlKey();

    /**
     * Get is active
     *
     * @return bool|int
     */
    public function getIsActive();

    /**
     * Get in rss
     *
     * @return bool|int
     */
    public function getInRss();

    /**
     * Get biography
     *
     * @return string
     */
    public function getBiography();

    /**
     * @return string
     */
    public function getProcessedBiography();



    /**
     * Get avatar
     *
     * @return string
     */
    public function getAvatar();



    /**
     * set id
     *
     * @param $id
     * @return AuthorInterface
     */
    public function setId($id);

    /**
     * set custom_name
     *
     * @param $customName
     * @return AuthorInterface
     */
    public function setCustomName($customName);



    /**
     * set url key
     *
     * @param $urlKey
     * @return AuthorInterface
     */
    public function setUrlKey($urlKey);

    /**
     * Set is active
     *
     * @param $isActive
     * @return AuthorInterface
     */
    public function setIsActive($isActive);

    /**
     * Set in rss
     *
     * @param $inRss
     * @return AuthorInterface
     */
    public function setInRss($inRss);

    /**
     * Set biography
     *
     * @param $biography
     * @return AuthorInterface
     */
    public function setBiography($biography);



    /**
     * set avatar
     *
     * @param $avatar
     * @return AuthorInterface
     */
    public function setAvatar($avatar);



    /**
     * Get created at
     *
     * @return string
     */
    public function getCreatedAt();




    /**
     * set created at
     *
     * @param $createdAt
     * @return AuthorInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated at
     *
     * @return string
     */
    public function getUpdatedAt();

    /**
     * set updated at
     *
     * @param $updatedAt
     * @return AuthorInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * @param $storeId
     * @return AuthorInterface
     */
    public function setStoreId($storeId);

    /**
     * @return AuthorInterface
     */
    public function getStoreId();
    // /**
    //  * @param $customMobile
    //  * @return AuthorInterface
    //  */
    // public function setCustomMobile($customMobile);
    // /**
    //  * @return AuthorInterface
    //  */
    // public function getCustomMobile();
    // /**
    //  * @param $gender
    //  * @return AuthorInterface
    //  */
    //   public function setGender($gender);
    //   /**
    //    * @return AuthorInterface
    //    */
      // public function getGender();


}
