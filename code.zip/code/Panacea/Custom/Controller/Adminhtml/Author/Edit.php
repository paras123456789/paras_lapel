<?php
/**
 * Panacea_Custom extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the MIT License
 * that is bundled with this package in the file LICENSE
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/mit-license.php
 *
 * @category  Panacea
 * @package   Panacea_Custom
 * @copyright 2016 Marius Strajeru
 * @license   http://opensource.org/licenses/mit-license.php MIT License
 * @author    Marius Strajeru
 */
namespace Panacea\Custom\Controller\Adminhtml\Author;

use Panacea\Custom\Controller\Adminhtml\Author;
use Panacea\Custom\Controller\RegistryConstants;

class Edit extends Author
{
    /**
     * Initialize current author and set it in the registry.
     *
     * @return int
     */
    protected function _initAuthor()
    {
        $authorId = $this->getRequest()->getParam('custom_id');
        $this->coreRegistry->register(RegistryConstants::CURRENT_SLIDER_ID, $authorId);

        return $authorId;
    }

    /**
     * Edit or create author
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $authorId = $this->_initAuthor();

        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Panacea_Custom::author');
        $resultPage->getConfig()->getTitle()->prepend(__('Customs'));
        $resultPage->addBreadcrumb(__('Customs'), __('Customs'));
        $resultPage->addBreadcrumb(__('Customs'), __('Customs'), $this->getUrl('panacea_custom/author'));

        if ($authorId === null) {
            $resultPage->addBreadcrumb(__('New Custom'), __('New Custom'));
            $resultPage->getConfig()->getTitle()->prepend(__('New Custom'));
        } else {
            $resultPage->addBreadcrumb(__('Edit Custom'), __('Edit Custom'));
            $resultPage->getConfig()->getTitle()->prepend(
                $this->authorRepository->getById($authorId)->getName()
            );
        }
        return $resultPage;
    }
}
