<?php
/**
 * Panacea_Custom extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the MIT License
 * that is bundled with this package in the file LICENSE
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/mit-license.php
 *
 * @category  Panacea
 * @package   Panacea_Custom
 * @copyright 2016 Marius Strajeru
 * @license   http://opensource.org/licenses/mit-license.php MIT License
 * @author    Marius Strajeru
 */
namespace Panacea\Custom\Controller\Adminhtml\Author;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Panacea\Custom\Controller\Adminhtml\Author;

class Delete extends Author
{
    /**
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $id = $this->getRequest()->getParam('custom_id');
        if ($id) {
            try {
                $this->authorRepository->deleteById($id);
                $this->messageManager->addSuccessMessage(__('The Custom has been deleted.'));
                $resultRedirect->setPath('panacea_custom/*/');
                return $resultRedirect;
            } catch (NoSuchEntityException $e) {
                $this->messageManager->addErrorMessage(__('The custom no longer exists.'));
                return $resultRedirect->setPath('panacea_custom/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
                return $resultRedirect->setPath('panacea_custom/author/edit', ['custom_id' => $id]);
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage(__('There was a problem deleting the custom'));
                return $resultRedirect->setPath('panacea_custom/author/edit', ['custom_id' => $id]);
            }
        }
        $this->messageManager->addErrorMessage(__('We can\'t find a custom to delete.'));
        $resultRedirect->setPath('panacea_custom/*/');
        return $resultRedirect;
    }
}
