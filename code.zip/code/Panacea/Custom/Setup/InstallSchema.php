<?php
/**
 * Panacea_Custom extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the MIT License
 * that is bundled with this package in the file LICENSE
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/mit-license.php
 *
 * @category  Panacea
 * @package   Panacea_Custom
 * @copyright 2016 Marius Strajeru
 * @license   http://opensource.org/licenses/mit-license.php MIT License
 * @author    Marius Strajeru
 */
namespace Panacea\Custom\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;


class InstallSchema implements InstallSchemaInterface
{
    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMD.Generic.CodeAnalysis.UnusedFunctionParameter)
     */
    // @codingStandardsIgnoreStart
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    // @codingStandardsIgnoreEnd
    {
        $installer = $setup;

        $installer->startSetup();

        if (!$installer->tableExists('custom')) {
            $table = $installer->getConnection()
                ->newTable($installer->getTable('custom'));
            $table->addColumn(
                    'custom_id',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'unsigned' => true,
                        'nullable' => false,
                        'primary' => true
                    ],
                    'Custom ID'
                )
                ->addColumn(
                    'custom_name',
                    Table::TYPE_TEXT,
                    255,
                    ['nullable'  => false,],
                    'Custom Name'
                )
                ->addColumn(
                    'price',
                    Table::TYPE_TEXT,
                    255,
                    ['nullable'  => false,],
                    'Price'
                )
                ->addColumn(
                    'url_key',
                    Table::TYPE_TEXT,
                    255,
                    ['nullable'  => false,],
                    'Author Url Key'
                )
                ->addColumn(
                    'biography',
                    Table::TYPE_TEXT,
                    '2M',
                    [],
                    'Author Biography'
                )
                ->addColumn(
                    'dob',
                    Table::TYPE_DATE,
                    null,
                    [],
                    'Author Birth date'
                )
                ->addColumn(
                    'awards',
                    Table::TYPE_TEXT,
                    '2M',
                    [],
                    'Author Awards'
                )
                ->addColumn(
                    'category',
                    Table::TYPE_INTEGER,
                    null,
                    [],
                    'Custom Category'
                )
                ->addColumn(
                    'avatar',
                    Table::TYPE_TEXT,
                    255,
                    [],
                    'Author Avatar'
                )

                ->addColumn(
                    'is_active',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'nullable'  => false,
                        'default'   => '1',
                    ],
                    'Is Author Active'
                )
                ->addColumn(
                    'in_rss',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'nullable'  => false,
                        'default'   => '1',
                    ],
                    'Show in rss'
                )
                ->addColumn(
                    'updated_at',
                    Table::TYPE_TIMESTAMP,
                    null,
                    [],
                    'Update at'
                )
                ->addColumn(
                    'created_at',
                    Table::TYPE_TIMESTAMP,
                    null,
                    [],
                    'Creation Time'
                )
                ->setComment('Custom authors');
            $installer->getConnection()->createTable($table);

            $installer->getConnection()->addIndex(
                $installer->getTable('custom'),
                $setup->getIdxName(
                    $installer->getTable('custom'),
                    ['name','photo'],
                    AdapterInterface::INDEX_TYPE_FULLTEXT
                ),
                [
                    'custom_name',
                    'biography',
                    'url_key',
                ],
                AdapterInterface::INDEX_TYPE_FULLTEXT
            );
        }

        //Create Authors to Store table
        if (!$installer->tableExists('panacea_custom_author_store')) {
            $table = $installer->getConnection()
                ->newTable($installer->getTable('panacea_custom_author_store'));
            $table->addColumn(
                    'custom_id',
                    Table::TYPE_INTEGER,
                    null,
                    [
                        'unsigned' => true,
                        'nullable' => false,
                        'primary'   => true,
                    ],
                    'Custom ID'
                )
                ->addColumn(
                    'store_id',
                    Table::TYPE_SMALLINT,
                    null,
                    [
                        'unsigned'  => true,
                        'nullable'  => false,
                        'primary'   => true,
                    ],
                    'Store ID'
                )
                ->addIndex(
                    $installer->getIdxName('panacea_custom_author_store', ['store_id']),
                    ['store_id']
                )
                ->addForeignKey(
                    $installer->getFkName('panacea_custom_author_store', 'custom_id', 'custom', 'custom_id'),
                    'custom_id',
                    $installer->getTable('custom'),
                    'custom_id',
                    Table::ACTION_CASCADE
                )
                ->addForeignKey(
                    $installer->getFkName('panacea_custom_author_store', 'store_id', 'store', 'store_id'),
                    'store_id',
                    $installer->getTable('store'),
                    'store_id',
                    Table::ACTION_CASCADE
                )
                ->setComment('Author To Store Link Table');
            $installer->getConnection()->createTable($table);
        }

    }
}
