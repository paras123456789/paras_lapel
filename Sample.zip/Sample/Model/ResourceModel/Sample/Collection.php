<?php
/**
* @author Dhirajkumar Deore
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Suit\Sample\Model\ResourceModel\Sample;

use \Suit\Sample\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'suit_sample_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Suit\Sample\Model\Sample', 'Suit\Sample\Model\ResourceModel\Sample');
        $this->_map['fields']['suit_sample_id'] = 'main_table.suit_sample_id';
    }
}
