<?php
/**
* @author Dhirajkumar Deore
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Suit\Sample\Model\Sample\Source;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Status
 */
class SampleStyle implements OptionSourceInterface
{

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {

        return [
            ['value' => '1', 'label' => __('Sample Single Breasted')],
            ['value' => '2', 'label' => __('Sample Double breasted')],
            ['value' => '3', 'label' => __('Sample StitMandarinch')]
        ];
    }
}
