<?php
/**
* @author Dhirajkumar Deore
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Suit\Sample\Model;

class Sample extends \Magento\Framework\Model\AbstractModel
{


    protected function _construct()
    {
        $this->_init('Suit\Sample\Model\ResourceModel\Sample');
    }


    public function getAvailableStatuses()
    {


        $availableOptions = ['1' => 'Enable',
                          '0' => 'Disable'];

        return $availableOptions;
    }
}
