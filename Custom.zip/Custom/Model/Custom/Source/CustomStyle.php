<?php
/**
* @author Dhirajkumar Deore
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Suit\Custom\Model\Custom\Source;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class Status
 */
class CustomStyle implements OptionSourceInterface
{

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {

        return [
            ['value' => '1', 'label' => __('Custom Single Breasted')],
            ['value' => '2', 'label' => __('Custom Double breasted')],
            ['value' => '3', 'label' => __('Custom StitMandarinch')]
        ];
    }
}
