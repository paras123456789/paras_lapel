<?php
/**
* @author Dhirajkumar Deore
* Copyright © 2018 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace Suit\Custom\Model\ResourceModel\Custom;

use \Suit\Custom\Model\ResourceModel\AbstractCollection;

class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'suit_custom_id';

    /**
     * Load data for preview flag
     *
     * @var bool
     */
    protected $_previewFlag;

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Suit\Custom\Model\Custom', 'Suit\Custom\Model\ResourceModel\Custom');
        $this->_map['fields']['suit_custom_id'] = 'main_table.suit_custom_id';
    }
}
